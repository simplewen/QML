#include "TreeModel.h"  

#if _MSC_VER >= 1600
#pragma execution_character_set("utf-8");
#endif
TreeModel::TreeModel(QObject *parent) :
	QAbstractItemModel(parent)
{
	int dataNum[20] = {0,1,2,3,4,5,6,7,8};
	m_rootItem = new TreeItem({ "����ͨ��" },dataNum+0);

    auto item1 = new TreeItem({ "�Ĵ�ʡ", "b" },dataNum+1);
    auto item2 = new TreeItem({ "��ǩ", "bb" },dataNum+2);
	auto item3 = new TreeItem({ "��������","bbb"},dataNum+3);
    auto item4 = new TreeItem({ "��è","b1" },dataNum+4);
    auto item5 = new TreeItem({ "��ʳ","b1" },dataNum+9);
	QList<QString> names;
	names.push_back("�ɶ�");
	names.push_back("����");
	names.push_back("�ϳ�");
    names.push_back("��ɽ");
    QList<QString> foods;
    foods.push_back("���");
    foods.push_back("ˮ����");
    foods.push_back("�ع���");
    foods.push_back("���Ŷ���");
	m_rootItem->appendChild(item1);
	item1->appendChild(item2);
	item1->appendChild(item3);
    item1->appendChild(item5);

	item2->appendChild(item4);
	for (int i= 0;i<names.count();i++)
	{
		QString name = names[i];
		item3->appendChild(new TreeItem({name},dataNum+i+5));
        QString food=foods[i];
        item5->appendChild(new TreeItem({food},dataNum+i+10));
	}
}

TreeModel::~TreeModel()
{
	delete m_rootItem;
}

int TreeModel::columnCount(const QModelIndex &parent) const
{
	if (parent.isValid())
	{
		return static_cast<TreeItem*>(parent.internalPointer())->columnCount();
	}
	else
	{
		return m_rootItem->columnCount();
	}
}

QHash<int, QByteArray> TreeModel::roleNames() const
{
	/*
	roleName�����Լ����壬�����������д��
	*/

	QHash<int, QByteArray> names(QAbstractItemModel::roleNames());
	names[12345] = "text";
	names[12346] = "text2";
	return names;
}

QVariant TreeModel::data(const QModelIndex &index, int role) const
{
	if (!index.isValid())
	{
		return QVariant();
	}

	switch (role)
	{
	case 12345:
	{
		return static_cast<TreeItem*>(index.internalPointer())->data(0);
	}
	case 12346:
	{
		return static_cast<TreeItem*>(index.internalPointer())->data(1);
	}
	case Qt::DisplayRole:
	{
		return static_cast<TreeItem*>(index.internalPointer())->data(index.column());
	}
	default:
	{
		return QVariant();
	}
	}
}

Qt::ItemFlags TreeModel::flags(const QModelIndex &index) const
{
	if (!index.isValid())
	{
		return 0;
	}

	return Qt::ItemIsEnabled | Qt::ItemIsSelectable;
}

QVariant TreeModel::headerData(int section, Qt::Orientation orientation, int role) const
{
	if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
	{
		return m_rootItem->data(section);
	}

	return QVariant();
}

QModelIndex TreeModel::index(int row, int column, const QModelIndex &parent) const
{
	if (!hasIndex(row, column, parent))
	{
		return QModelIndex();
	}

	TreeItem *parentItem;
	if (!parent.isValid())
	{
		parentItem = m_rootItem;
	}
	else
	{
		parentItem = static_cast<TreeItem*>(parent.internalPointer());
	}

	TreeItem *childItem = parentItem->child(row);
	if (childItem)
	{
		return createIndex(row, column, childItem);
	}
	else
	{
		return QModelIndex();
	}
}

QModelIndex TreeModel::parent(const QModelIndex &index) const
{
	if (!index.isValid())
	{
		return QModelIndex();
	}

	TreeItem *childItem = static_cast<TreeItem*>(index.internalPointer());
	TreeItem *parentItem = childItem->parent();

	if (parentItem == m_rootItem)
	{
		return QModelIndex();
	}

	return createIndex(parentItem->row(), 0, parentItem);
}

int TreeModel::rowCount(const QModelIndex &parent) const
{
	TreeItem *parentItem;
	if (parent.column() > 0)
	{
		return 0;
	}

	if (!parent.isValid())
	{
		parentItem = m_rootItem;
	}
	else
	{
		parentItem = static_cast<TreeItem*>(parent.internalPointer());
	}

	return parentItem->childCount();
}

QAbstractItemModel *TreeModel::model()
{
	return this;
}
int TreeModel::getData(const QModelIndex &index)
{
	void* a= static_cast<TreeItem*>(index.internalPointer())->getRecordData();
	int data = *(int*)a;
	return data;
}
