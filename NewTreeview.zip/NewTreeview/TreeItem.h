#ifndef TREEITEM_H  
#define TREEITEM_H  

// C lib import  
#include <assert.h>  

// Qt lib import  
#include <QList>  
#include <QVariant>  
#include <QStringList>  

class TreeItem
{
private:
	TreeItem *m_parentItem;
	QList<TreeItem*> m_childItems;
	QList<QVariant> m_itemData;
	void *m_recordData;

public:
	TreeItem(const QList<QVariant> &data,void *inputdata);

	~TreeItem();

	void appendChild(TreeItem *child);

	TreeItem *child(int row);

	int childCount() const;

	int columnCount() const;

	QVariant data(int column) const;

	int row() const;

	TreeItem *parent();

	void setParent(TreeItem *parent);
	void *getRecordData();
};
#endif  