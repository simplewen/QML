#include "TreeItem.h"  

TreeItem::TreeItem(const QList<QVariant> &data, void *inputdata)
{
	m_recordData = malloc(100);
	m_itemData = data;
	//m_recordData = inputdata;
	memcpy_s(m_recordData,sizeof(m_recordData),inputdata,sizeof(inputdata));
}

TreeItem::~TreeItem()
{
	qDeleteAll(m_childItems);
	if (m_recordData)
	{
		delete m_recordData;
		m_recordData = NULL;
	}
}

void TreeItem::appendChild(TreeItem *item)
{
	item->setParent(this);
	m_childItems.append(item);
}

TreeItem *TreeItem::child(int row)
{
	return m_childItems.value(row);
}

int TreeItem::childCount() const
{
	return m_childItems.count();
}

int TreeItem::columnCount() const
{
	return m_itemData.count();
}

QVariant TreeItem::data(int column) const
{
	return m_itemData.value(column);
}

TreeItem *TreeItem::parent()
{
	assert(m_parentItem);
	return m_parentItem;
}

void TreeItem::setParent(TreeItem *parent)
{
	m_parentItem = parent;
}

int TreeItem::row() const
{
	if (!m_parentItem) { return 0; }

	return m_parentItem->m_childItems.indexOf(const_cast<TreeItem*>(this));
}
void * TreeItem::getRecordData() 
{
	
	return m_recordData;
	
}